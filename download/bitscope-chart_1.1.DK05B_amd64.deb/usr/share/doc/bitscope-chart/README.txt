 ---------------------------------------------------------------------

           BITSCOPE CHART - A FREQUENCY AND VOLTAGE LOGGER

                 BETA Version 1.1 Build DK05B

              http://www.bitscope.com/software/chart/

   Copyright (C) 2010~2013 by BitScope Designs. All Rights Reserved.

 --------------------------------------------------------------------

 BitScope Chart measures periodic waveforms captured in real-time
 with BitScope. It locks onto a waveform frequency and peak amplitude
 to measure and report the major waveform parameters. The fundamental
 frequency and  period, RMS, minimum, maximum,  mean and peak-to-peak
 voltages are all reported. Data is presented as a chart over time.
 All data can be easily recorded to disk.

 Chart is fully automatic  and the parameter updates are reported
 dynamically as the waveform changes.  It also shows a scaled display
 of the waveform  itself with auto-ranging control of  the inputs and
 sample rates to optimize the measurements.

 You can think of Chart as a sophisticated AC voltage and frequency
 meter which logs data over time.

 Chart is available on Windows (WinXP, Vista and W7) and Linux.

 --------------------------------------------------------------------
 PACKAGE INSTALLTION                                    (.deb or .rpm)

 If you're using the .deb or .rpm versions of the archive install the
 package file as you normally do for any other package on your system.

 When Chart is installed a new desktop menu item should appear in
 (probably in "Other") from where you can run the application.

 You can also run it by typing bitscope-chart in an xterm.

 --------------------------------------------------------------------
 TARBALL INSTALLATION                                          (.tgz)

 If you've download the .tgz archive, unpack it somehere convenient.

 You can run Chart from  inside the unpacked archive (simply type
 ./bitscope-chart) or  you can copy the  executable to /usr/local/bin
 to "install it".

 Nothing else needs to be done to  use it but you will need to ensure
 you have X  and Gtk2 installed on your system. If  you use Gnome all
 you need will  be installed already. If you run KDE  you may need to
 install some libraries; the complete list of library dependencies is
 libatk1.0 libc6 libglib2.0 libgtk2.0 libpango1.0 and libx11-6.

 --------------------------------------------------------------------
 DEVICE SETUP

 Under most circumstances you  should not need to configure Chart
 to be able to connect with BitScope. Just click the CONNECT button.

 If your BitScope is not found  by Chart but you know where it is
 (eg /dev/ttyUSB3) click SETUP  and choose the appropriate connection
 (USB and /dev/ttyUSB3 in this example).

 For details about how Chart finds BitScope read bitscope.prb.

 --------------------------------------------------------------------
 OPERATING INSTRUCTIONS
 
 Online help is available for Chart. 

 Simply click the BitScope Logo or press F1 when Chart is started.

 This documentation is editable as you read it so if you want to make
 notes or change it as you learn to use Chart you can.
 
 --------------------------------------------------------------------
 BETA TESTING FEEDBACK

 This software  is in limited  beta release for testing  purposes. IT
 HAS KNOWN  BUGS but should be stable  for normal use. If  you do not
 wish to  participate in the beta  program please use stable release 
 (DSO 1.0) instead.

 Send any comments, bug reports, suggestions to support@bitscope.com.
 
 For full details of bug fixes see the FIX.txt file.
 --------------------------------------------------------------------
                BitScope Designs. Nov 12, 2013
 --------------------------------------------------------------------
